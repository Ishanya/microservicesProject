package com.ntl.microservices.MicroSRSAdmin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroSrsAdminApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroSrsAdminApplication.class, args);
	}
}
