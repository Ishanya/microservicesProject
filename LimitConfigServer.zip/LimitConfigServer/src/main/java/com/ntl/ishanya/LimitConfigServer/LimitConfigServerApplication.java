package com.ntl.ishanya.LimitConfigServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LimitConfigServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(LimitConfigServerApplication.class, args);
	}
}
