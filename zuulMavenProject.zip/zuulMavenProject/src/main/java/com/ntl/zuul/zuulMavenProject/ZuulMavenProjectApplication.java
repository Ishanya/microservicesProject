package com.ntl.zuul.zuulMavenProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZuulMavenProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZuulMavenProjectApplication.class, args);
	}
}
