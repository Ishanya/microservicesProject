package com.ntl.microservices.MicroSRSCustomer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroSrsCustomerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroSrsCustomerApplication.class, args);
	}
}
